<?php
// Check if form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Database connection parameters
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "review";

    // Create connection
    $conn = new mysqli($servername, $username, $password, $dbname);

    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Prepare data for insertion
    $name = $_POST['name'];
    $stars = $_POST['stars'];
    $description = $_POST['description'];
    
    // Handle profile photo upload
    $profile_photo = '';
    if ($_FILES['profile_photo']['error'] == 0) {
        $target_dir = "uploads/";
        $target_file = $target_dir . basename($_FILES["profile_photo"]["name"]);
        move_uploaded_file($_FILES["profile_photo"]["tmp_name"], $target_file);
        $profile_photo = $target_file;
    }

    // Prepare SQL statement
    $stmt = $conn->prepare("INSERT INTO reviews (name, stars, description, profile_photo) VALUES (?, ?, ?, ?)");
    $stmt->bind_param("siss", $name, $stars, $description, $profile_photo);

    // Execute SQL statement
    if ($stmt->execute() === TRUE) {
        echo "Review added successfully";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }

    // Close connection
    $stmt->close();
    $conn->close();
}
?>
