// Function to fetch reviews from the server
function fetchReviews() {
    fetch('fetch_reviews.php')
    .then(response => response.json())
    .then(reviews => {
        const reviewSection = document.querySelector('.review .box-container');
        reviewSection.innerHTML = ''; // Clear existing reviews

        // Loop through fetched reviews and add them to the review section
        reviews.forEach(review => {
            const box = document.createElement('div');
            box.classList.add('box');

            // Construct review HTML including profile photo
            const reviewHTML = `
            <img src="${review.profile_photo}" alt="Profile Photo">
            <h3>${review.name}</h3>
            <div class="stars">${getStarsHTML(review.stars)}</div>
            <p class="text">${review.description}</p>

            `;

            // Set inner HTML of the box element
            box.innerHTML = reviewHTML;

            // Append the box element to the review section
            reviewSection.appendChild(box);
        });
    })
    .catch(error => console.error('Error fetching reviews:', error));
}

// Function to generate star icons based on rating
function getStarsHTML(stars) {
    const fullStars = Math.floor(stars);
    const halfStar = stars % 1 !== 0;

    let starsHTML = '';
    for (let i = 0; i < fullStars; i++) {
        starsHTML += '<i class="fas fa-star"></i>';
    }

    if (halfStar) {
        starsHTML += '<i class="fas fa-star-half-alt"></i>';
    }

    return starsHTML;
}

// Fetch reviews when the page loads
document.addEventListener('DOMContentLoaded', fetchReviews);
