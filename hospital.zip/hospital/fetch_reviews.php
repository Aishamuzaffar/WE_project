<?php
// Establish a connection to the database
$conn = mysqli_connect('localhost', 'root', '', 'review') or die('Connection failed');

// Query to fetch reviews
$query = "SELECT name, stars, description, profile_photo FROM reviews";

$result = mysqli_query($conn, $query);

if ($result) {
    // Fetch associative array
    $reviews = mysqli_fetch_all($result, MYSQLI_ASSOC);

    // Encode reviews as JSON and output
    echo json_encode($reviews);
} else {
    echo json_encode(['error' => 'Failed to fetch reviews']);
}

// Close database connection
mysqli_close($conn);
?>
